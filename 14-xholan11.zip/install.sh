#!/bin/bash
echo sfc | sudo -S apt install python3 python3-pip python3-numpy python3-pyqt5 -y
